import { Menu, message , Button } from 'antd'
import React from 'react'
import {DeleteOutlined} from '@ant-design/icons'
import { deleteFavoriteItem } from '../utils'
 
function MenuItem({ items , favoriteOnChange }) {

    const deleteOnClick = (item) => {
        deleteFavoriteItem(item).then(() => {
            favoriteOnChange();
            console.log("did it")
        }).catch(err => {
            message.error(err.message)
        })
    }

  return items.map((item) => (
    <Menu.Item key={item.id}>
        <div style={{display:"flex", justifyContent:"space-between"}}>
            <a href={item.url} target="_blank" rel="noopener noreferrer">
            {`${item.broadcaster_name} - ${item.title}`}
            </a>
            <Button shape='circle' icon={<DeleteOutlined style={{ fontSize: '20px'}} />} onClick={() => deleteOnClick(item)} />
        </div>
        
    </Menu.Item>
  )
  )
}
 
export default MenuItem